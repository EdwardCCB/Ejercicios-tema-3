// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        // Press Alt+Intro with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        var a = 2;
        var b = 3;
        var c = 5;
        System.out.println(suma(a, b, c));
        Coche miCoche = new Coche();
        miCoche.AgregarPuerta();
        miCoche.AgregarPuerta();
        miCoche.AgregarPuerta();
        miCoche.AgregarPuerta();
        System.out.println(miCoche.coche);
        }
        public static int suma (int a, int b, int c) {
            return a + b + c;
        }

    }
class Coche {
    public int coche = 0;

    public void AgregarPuerta() {
        this.coche++;
    }
}